function Signin() {
	
	var needVerifyCode = true;
	
	var loginAccountTypeDropList = null;
	
	this.init = function($Scope) 
	{
		debugger;
		//禁用F12	
		$Scope.$Get('$Fire')({
		    service: "/gadget/sm/SysParamAction/isBesDisabledDebug",
		    target : "$Model.isBesDisabledDebug"
		},$Scope);
		
		var $Model = $Scope.$Model;
		// 获取上次登录的账号
		var lastLoginId = $.cookie('lastLoginId');
		if (lastLoginId) {
			$Model.name = lastLoginId;
			$.cookie('lastLoginId', '');
		}
		//uee 解决u-locale问题
		var lang = jQuery.cookie('bes_login_locale');
		if (lang == undefined) {
			lang = "es_CO"
		}
		if (lang)
		{
			$Model.langProperty = lang;
		}
		
		$(".uee-field-label").css("width", "100px");
		
		// 防止粘贴密码
		$("#ipt_pwd").on("paste", function() {
			return false;
		});
		
		// cookieName需改成可配置的，现临时写死
		// 为解决UEE的u-locale为session级别，导致切换语言在浏览器关闭后重新打开失效而临时规避的方案
		var smLoginLocale = jQuery.cookie('bes_login_locale');
		var ueeLocale = jQuery.cookie('u-locale');
		if (smLoginLocale != undefined && smLoginLocale != ueeLocale)
		{
			jQuery.cookie('u-locale', smLoginLocale, {path:"/"});
		}
		
		var $fire = $Scope.$Get("$Fire");
		
		$fire({
			      "service" : "SMLoginAction/getVerifyCodeSysParam",
			      "params" :  {},
			      "target" : "$Model.vcodeResult",
			 },$Scope).onafter(function(){
			 	
		      //读取系统参数，判断是否使用验证码
					if ($Model.vcodeResult && $Model.vcodeResult == "N")
					{
						needVerifyCode = false;
						$("#vcodeField").css("display","none");
					}
					else
					{				
						needVerifyCode = true;
						$("#vcodeField").css("display","block");
						
						refreshVerifycode();
					}					
					
	    });	

		//读取系统语言
	    var selObj = $('.langClass');
	    var dic = $Model.languageProperty;
	    for(var key in dic) {
	        var opt1 = getLangDiv(key, dic[key]); 
	        selObj.append(opt1);
	    }
	    selObj.val($Model.langProperty);
	    
	    // 生成登录的语言
	    signin.genLoginLocale($Model.langProperty, $Model.languageProperty);
	    
	    $fire({
		      "service" : "SMLoginAction/getLoginRandomValue",
		      "target" : "$Model.loginRandomValue",
		 },$Scope);
	    
	    $fire({
		      "service" : "SMLoginAction/getLoginPagePluginsUrl",
		      "target" : "$Model.pluginsUrl",
		 },$Scope).onafter(function(){
			 $("#LOGIN_CRM_BASE_PLUGINS").text($Model.pluginsUrl.PLUGINS_1_NAME);
			 $("#LOGIN_DESKTOP_MANAGER_VALUE").text($Model.pluginsUrl.PLUGINS_2_NAME);
		     $(document).attr("title", $Model.pluginsUrl.LOGIN_TITLE);
		     $("#LOGIN_LABEL_COPYRIGHT").text($Model.pluginsUrl.COPYRIGHT);
		     var shortcutPath = $Model.pluginsUrl.SHORTCUT_ICON_PATH;
		     if (shortcutPath != undefined && shortcutPath != null && shortcutPath != "")
		     {
		         var linkTag = "<link rel=\"shortcut icon\" type=\"image/ico\" href=\"" + shortcutPath + "\" /> "
		         $($('head')[0]).append(linkTag); 
		     }
	    });	
	    
	    $fire({
		      "service" : "SMLoginAction/getInitParams",
		      "params" :  {"local": $Model.langProperty},
		      "target" : "$Model.initParams",
      },$Scope).onafter(function(){
			// 设置title
          $(document).attr("title", $Model.initParams.title);
          
          // 设置版权信息
		    $("#LOGIN_LABEL_COPYRIGHT").text($Model.initParams.copyright);
		    
		    // 设置shortcut icon 路径
		    var shortcutPath = $Model.initParams.shortcutIconPath;
		    if (shortcutPath != undefined && shortcutPath != null && shortcutPath != "")
		    {
		        var linkTag = "<link rel=\"shortcut icon\" type=\"image/ico\" href=\"" + shortcutPath + "\" /> "
		        $($('head')[0]).append(linkTag); 
		    }	 
			
		    //add begin 2017-09-24  获取IP地址
			debugger;
			$fire({
			      "service" : "/checkclientip/ipexistinrange",
			      "target" : "$Model.ipResult",
			 },$Scope).onafter(function(){
				    // 设置图形验证码
					if (!$Model.ipResult || $Model.initParams.needGraphicVerifyCode)
					{
						needVerifyCode = true;
						$("#vcodeField").css("display","block");
						refreshVerifycode();
					}
					else
					{				
						needVerifyCode = false;
						$("#vcodeField").css("display","none");
					}	
			 });

			//add end  2017-09-24
				
			// 设置插件地址
			if ($Model.initParams.plugins != undefined)
			{
				if ($Model.initParams.plugins.PLUGINS_1 != undefined)
				{
					$("#LOGIN_CRM_BASE_PLUGINS").text($Model.initParams.plugins.PLUGINS_1.name);	
				}
				
				if ($Model.initParams.plugins.PLUGINS_2 != undefined)
				{
					$("#LOGIN_DESKTOP_MANAGER_VALUE").text($Model.initParams.plugins.PLUGINS_2.name);	
				}
			}
			
			// 设置账户类型
			if ($Model.initParams.accountTypes != undefined && $Model.initParams.accountTypes.length > 0)
			{
				var accountTypeList = [];
				var accountType = {};
				if ($Model.initParams.accountTypes.length > 1) {
					accountType.key = "";
					accountType.value = $UEE.i18n('SM.LOGIN.TITLE.SELECT_ACCOUNT_TYPE');
					accountTypeList.push(accountType);
					var option = $('<option></option>');
					option.attr('value', accountType.key);
					option.text(accountType.value);
					$('#accountTypeSelect').append(option);
				}
              for (var i=0; i<$Model.initParams.accountTypes.length; i++)
              {
              	accountType = {};
              	accountType.key = $Model.initParams.accountTypes[i].id;
              	accountType.value = $Model.initParams.accountTypes[i].name;
              	if (i==0)
              	{
              		accountType.selected = true;
					$Model.selectedAccountType = accountType.key;
              	}
              	accountTypeList.push(accountType);

				  var option = $('<option></option>');
				  option.attr('value', accountType.key);
				  if (i==0) {
					  option.attr('selected', true);
				  }
				  option.text(accountType.value);
				  $('#accountTypeSelect').append(option);
              }
				
				// 根据最大字符串长度设置下拉框宽度
				if (jQuery.cookie("u-locale")=="zh_CN")
				{
					$("#loginAccountTypes>div").width(143);
				}
				else if (jQuery.cookie("u-locale")=="en_US")
				{
					$("#loginAccountTypes>div").width(235);
				}
				else{
					// 其它语言暂时设置为300
					$("#loginAccountTypes>div").width(300);
				}
			}
			if ($Model.selectedAccountType == 'OAuth') {
				document.getElementById("uee-name").style.display="none";
				document.getElementById("uee-password").style.display="none";
			} else {
				document.getElementById("uee-name").style.display="";
				document.getElementById("uee-password").style.display="";
			}
		});	
	    
	    // 显示登出原因
	    var logoutReason = $Scope.$Params.logoutReason;
	    var i18n = $UEE.i18n;
	    if (logoutReason == "NoLogin")
	    {
	    	// 会话超过上限踢出
	    	signin.showError(i18n('SM.LOGIN.MESSAGE.LOGOUT_REASON.NO_LOGIN'));
	    }
	    else if (logoutReason == "SessionInvalid")
	    {
	    	// 会话失效
	    	signin.showError(i18n('SM.LOGIN.MESSAGE.LOGOUT_REASON.SESSION_INVALID'));
	    }
	    else if (logoutReason == "IPCheckFailed")
	    {
	    	// IP校验失败
	    	signin.showError(i18n('SM.LOGIN.MESSAGE.LOGOUT_REASON.IP_CHECK_FAILED'));
	    }
	    else if (logoutReason == "ForceChangePassword")
	    {
	    	// 强制修改密码
	    	signin.showError(i18n('SM.LOGIN.MESSAGE.LOGOUT_REASON.FORCE_CHANGE_PASSWORD'));
	    }
	    
	    signin.getSignIn();
		var currentURl = window.location.href;
		var urlSplit = currentURl.split("?");
		if (urlSplit.length > 1 && urlSplit[1].startsWith("code=")) {
			document.getElementById("loginBtn").style.display="none";
			document.getElementById("localeDiv").style.display="none";
			signin.showInfo(i18n('SM.LOGIN.MESSAGE.OAUTH_LOGIN'));
			// Oauth 调登录流程
			var loginparam = {};
			loginparam.locale = $Model.langProperty;
			loginparam.accountType = "OAuth";
			var params = urlSplit[1].substring(5);
			var paramSplit = params.split("&");
			loginparam.oAuthCode = paramSplit[0];
			if ($(document).scope().$Webapp == "/operator") {
				loginparam.loginPortal = "OP"
			} else {
				loginparam.loginPortal = "OC"
			}
			loginparam.redirectUri = urlSplit[0]
			$fire({
				"service" : "SMAuthenticateAction/authenticatelogin",
				"params" :  {'loginparam':loginparam},
				"target" : "$Model.authResult",
				"onerror" : "signin.onAuthException($Model)"
			},$Scope).onafter(function(){
				debugger;
				signin.onAuthAfter($Scope);
			});
		}
	};

	// 发送方式变更
	this.accountTypeOnChange = function(key) {
		debugger
		var $Model = $(document).scope().$Model;
		$Model.selectedAccountType = key;
		if ($Model.selectedAccountType == 'OAuth') {
			document.getElementById("uee-name").style.display="none";
			document.getElementById("uee-password").style.display="none";
		} else {
			document.getElementById("uee-name").style.display="";
			document.getElementById("uee-password").style.display="";
		}
	};
	
	this.genLoginLocale = function(currentLocale, locales) {
		var localeDiv = $('#localeDiv');
		for (var locale in locales) {
			
			var langDiv = $('<div class="uee-en-ch"></div>');
			var a = $('<a></a>');
			a.append(locales[locale]);
			a.attr('locale', locale);
			if (currentLocale == locale) {
				a.attr('class','active');
			} else {
				a.attr('style','cursor:pointer');
				a.attr('class', 'changelocale');
			}
			langDiv.append(a);			
			localeDiv.append(langDiv);
		}
	}
	

		this.getSignIn = function() {
		// alert(1);
		debugger;
		var $Scope = $("#ipt_name").scope();
		var $fire = $Scope.$Get("$Fire");
		var $Model = $Scope.$Model;
		$fire({
			"service" : "/SMIsOnlyUseDomainAccount/isOnlyUseDomainAccount",
			"target" : "$Model.isOnlyUseDomainAccount",
		}, $Scope)
				.onafter(
						function() {
							debugger;
							if ("Y" == $Model.isOnlyUseDomainAccount) {
								$("#accountTypeSelect").empty();
								var accountTypeList = [];
								var accountType = {};
								var account = $Model.name;
								if ("101" == account) {
									// 设置账户类型
									if ($Model.initParams.accountTypes != undefined && $Model.initParams.accountTypes.length > 1) {

										accountType.key = $Model.initParams.accountTypes[0].id;
										accountType.value = $Model.initParams.accountTypes[0].name;

										accountType.selected = true;
										accountTypeList.push(accountType);
										var option = $('<option></option>');
										option.attr('value', accountType.key);
										option.text(accountType.value);
										$('#accountTypeSelect').append(option);
										// }

										if ($Model.initParams.accountTypes.length > 2) {
											var option = $('<option></option>');
											option.attr('value', $Model.initParams.accountTypes[2].id);
											option.text($Model.initParams.accountTypes[2].name);
											$('#accountTypeSelect').append(option);
										}

										$Model.selectedAccountType = accountType.key;

										// 根据最大字符串长度设置下拉框宽度
										if (jQuery.cookie("u-locale")=="en_US")
										{
											$("#loginAccountTypes>div").width(235);
										}
										else{
											// 其它语言暂时设置为300
											$("#loginAccountTypes>div").width(300);
										}
									}
								} else {
									if ($Model.initParams.accountTypes != undefined && $Model.initParams.accountTypes.length > 1) {

										accountType.key = $Model.initParams.accountTypes[1].id;
										accountType.value = $Model.initParams.accountTypes[1].name;

										accountType.selected = true;
										accountTypeList.push(accountType);
										var option = $('<option></option>');
										option.attr('value', accountType.key);
										option.text(accountType.value);
										$('#accountTypeSelect').append(option);
										// }
										if ($Model.initParams.accountTypes.length > 2) {
											var option = $('<option></option>');
											option.attr('value', $Model.initParams.accountTypes[2].id);
											option.text($Model.initParams.accountTypes[2].name);
											$('#accountTypeSelect').append(option);
										}
										$Model.selectedAccountType = accountType.key;

										if (jQuery.cookie("u-locale")=="en_US")
										{
											$("#loginAccountTypes>div").width(235);
										}
										else{
											// 其它语言暂时设置为300
											$("#loginAccountTypes>div").width(300);
										}

									}
								}
								if ($Model.initParams.accountTypes != undefined && $Model.initParams.accountTypes.length == 1){
									accountType.key = $Model.initParams.accountTypes[0].id;
									accountType.value = $Model.initParams.accountTypes[0].name;

									accountType.selected = true;
									accountTypeList.push(accountType);
									var option = $('<option></option>');
									option.attr('value', accountType.key);
									option.text(accountType.value);
									$('#accountTypeSelect').append(option);
									$Model.selectedAccountType = accountType.key;
								}
							}
						})
	}
	
	this.hiddenError = function(val) {
		$("#div_error").css({
			visibility : "hidden"
		});
	};

	this.changeLanguage = function($Scope, jEvent) {
		debugger;
	    var $Model = $Scope.$Model;		
		$Model.langProperty = lanNow;
		var lanNow = $(jEvent.target).attr('locale');
	    //get values
		var username = $Model.name;			
		var language = lanNow;		
		
		var lastLoginId = $Model.name;
		if (lastLoginId) {
			$.cookie('lastLoginId', $Model.name);
		}
		
		//call service
		var $fire = $Scope.$Get("$Fire");
		$fire({
		      	"service" : "SMLoginAction/languageChange",
		      	"params" :  {'name':username,'language':language},
		      	"target" : "$Model.changeLangResult",
			 },$Scope).onafter(function(){
				 window.location.reload();
			 });
	};
		
	// 跳转页面函数
	this.forwardUrl = function(url, jsonObj) {
		debugger;

		signin.popVerifyTokenWin(url, jsonObj);

	};
	
	this.popVerifyTokenWin = function(url,jsonObj){
		var $Scope = $(document).scope();
		var $Fire = $Scope.$Get('$Fire');
		var $Model = $Scope.$Model;

			   $Fire({
					service : "/check/ischecktoken",
					target : "$Model.isNeedCheckSMSVerfiyCode"
				},$Scope).onafter(function(){
					debugger;
					//需要校验手机验证码
					//加上校验是否在规定的ip段内
					if(!$Model.ipResult || $Model.isNeedCheckSMSVerfiyCode == "1"){
						debugger;
						$Model.saveUrl = url;
						$Model.saveJsonObj = jsonObj;
						var i18n = $UEE.i18n;
						$Fire({"popup" : {'title' : i18n('SM.LOGIN.CTZ.TITLE.LOGIN'),'width' : '560px','height' : '200px','modal' : true, 'src':'resource.root/bes/sm/login/uslx/verify_sms_token.uslx'}
						      },$Scope);
					}else{
						//modify begin 需要校验员工的组织和权限
						$Fire({
							service : "/check/checkemployeeauthordept"
						},$Scope).onsuccess(function(){
							signin.isNeedChangeChooseOrg(url, jsonObj);
						}).onerror(function(){
							$Model.checkToken = $Scope.$Error.title;
							$Fire({"popup" : {'title' : $UEE.i18n('SM.LOGIN.CTZ.TITLE.PROMPT'),'width' : '400px','height' : '220px','modal' : true, 'src':'resource.root/bes/sm/login/uslx/verify_sms_auth.uslx'}
						      },$Scope);
							return false;
						})
						//modify end
					}
				});
//		 });
		
	};
	
	//校验手机验证码服务
	this.verifyTokenREST = function($Scope){
		var $Fire = $Scope.$Get('$Fire');
		var $Model = $Scope.$Model;
		$Fire({
			service : "/check/checktoken",
			params : {"token" : $Model.inputToken},
		},$Scope).onsuccess(function(){
			
			signin.isNeedChangeChooseOrg($Model.saveUrl, $Model.saveJsonObj);
		}).onerror(function(){
			debugger;
			if($Scope.$Error.errorCode == "60101020062"){
				$Model.checkToken = $Scope.$Error.title;
			}else{
				$Model.checkToken = $Scope.$Error.cause;
			}
			$Fire({"popup" : {'title' : $UEE.i18n('SM.LOGIN.CTZ.TITLE.PROMPT'),'width' : '400px','height' : '220px','modal' : true, 'src':'resource.root/bes/sm/login/uslx/verify_sms_auth.uslx'}
		      },$Scope);
			return false;
		});
		
	};
	
	//取消重定向到登录首页
	this.clearSession = function($Scope){
		var $fire1 = $Scope.$Inject("$Fire");
		$fire1({
			"service" : "/SMLogoutAction/logout"
		},$Scope).onafter(function(){
			window.top.location.href = $(document).scope().$Webapp + "/bes/sm/login/login-colombia.html";
		});
	};
	
	//页面重定向到登陆后的首页
	this.lastforwardUrl = function(url,jsonObj){
		debugger;
		var fwURL;
		if (typeof url == "object") {
			fwURL = url.url;
		} else {
			fwURL = url;
		}
		
		var $Scope = $(document).scope();
		if (jsonObj.visitBelongedSystem)
		{
			window.top.location.href = fwURL;
		}
		else
		{
			window.top.location.href = $(document).scope().$Webapp + "/bes/sm/login/confirm.html?currSysURL=" + encodeURIComponent(fwURL) + "&belongedURL=" + encodeURIComponent(jsonObj.belongedSystemURL);
		}
	};
	
	//判断是否选择登陆组织
	this.isNeedChangeChooseOrg = function(url,jsonObj){
		var $Scope = $(document).scope();
		
		var $Fire = $Scope.$Get("$Fire");
		var $Model = $Scope.$Model;
		$Fire({
			"service" :"/gadget/sm/SysParamAction/isShowSwitchOrg",
			"target" : "$Model.isNeedChooseOrg"
		},$Scope).onafter(function(){
			if("Y" == $Model.isNeedChooseOrg){
				//判断是否需要选择组织
				signin.chooseSecondmentOrg(url, jsonObj);
			}else{
				//不需要选择组织直接登陆
				signin.lastforwardUrl(url,jsonObj);
				
			}
		});
	};
	
	this.chooseSecondmentOrg = function(url,jsonObj){
		var $Scope = $(document).scope();
		
		var $Fire = $Scope.$Get("$Fire");
		var $Model = $Scope.$Model;
		
		$Fire({
			"service" : "/sm/login/switchdata/initSwitchOrgData",
			"target" : "$Model.chooseSecondments"
		},$Scope).onafter(function(){
			
			
			if($Model.chooseSecondments.length <= 1){
				//不需要选择组织直接登陆
				signin.lastforwardUrl(url,jsonObj);
			}else{
				$Model.jumpUrl = url;
				$Model.jumpJsonObj = jsonObj;
				
				//设置第一个值为默认选择组织
				$Model.chooseSecondmentId = $Model.chooseSecondments[0].orgId; 
				//弹出组织选择框
				var i18n = $UEE.i18n;
				$Fire({"popup" : {'title' : i18n('SM.LOGIN.TITLE.CHOOSE_ORG_LIST'),'width' : '560px','height' : '200px','modal' : true, 'src':'resource.root/bes/sm/login/uslx/login_choose_org.uslx'}
				      },$Scope);
			}
			
		});
	};
	
	this.confirmChooseOrg = function($Scope){
		var $Fire = $Scope.$Get("$Fire");
		var $Model = $Scope.$Model;
		
		$Fire({
			"service" : "/sm/login/switchdata/setOrgInfoContext",
			"params" : {"relId" : $Model.chooseSecondmentId},
	        "target" : "$Gadget.switchMap"
		},$Scope).onsuccess(function(){
			//成功跳转等首页
			signin.lastforwardUrl($Model.jumpUrl,$Model.jumpJsonObj);
		});
	};
	
	this.request = function(param) {
		var url = location.href;

		var paraString = url.substring(url.indexOf("?") + 1, url.length).split("&");
		var paraObj = {};

		for ( var i = 0; i < paraString.length; i++) {
			var j = paraString[i];

			paraObj[j.substring(0, j.indexOf("=")).toLowerCase()] = j.substring(j
					.indexOf("=") + 1, j.length);
		}

		var returnValue = paraObj[param.toLowerCase()];

		if (typeof (returnValue) == "undefined") {
			return "";
		} else {
			return returnValue;
		}

	};	
	
	// 用户登录
	this.login = function($Scope) 
	{
		debugger;
		var i18n = $UEE.i18n;
		
		// 避免重复提交	
		if (window.issubmited) 
		{
			alert(i18n('SM.LOGIN.MESSAGE.REPEAT_SUBMITED'));
			return;
		}
		var $Model = $Scope.$Model;
		
		var accountType = $Model.selectedAccountType;
		if (accountType == undefined || accountType == "")
		{
			signin.showError(i18n('SM.LOGIN.TITLE.SELECT_ACCOUNT_TYPE'));
			return;
		}
		

		var username = $Model.name;			
		var pwd = $Model.pwd;				
		var language = $Model.langProperty;
		var vcode = $Model.vcode;

		// 校验输入框是否都已必填
		var $fire = $Scope.$Inject("$Fire");

		if ($Model.selectedAccountType == "OAuth") {
			$fire({
				"service" : "/smoauthctz/queryOAuthEntityConfig",
				"params" :  {'request': {logicKey:"OAuth"}},
				"target" : "$Model.oAuthEntityResult",
			},$Scope).onafter(function(){
				if (!$Model.oAuthEntityResult) {
					return
				}
				var currentURL = window.location.href.split("?")[0];
				var url;
				if ($(document).scope().$Webapp == "/operator") {
					url = $Model.oAuthEntityResult.AuthorizationURL + "?client_id=" + $Model.oAuthEntityResult.OP_ClientID + "&redirect_uri=" +
						encodeURIComponent(currentURL) + "&lang=" + language.substring(0, 2) + "&scope=" + $Model.oAuthEntityResult.Scope + "&response_type=" +
						$Model.oAuthEntityResult.ResponseType + "&response_mode=" + $Model.oAuthEntityResult.ResponseMode + "&state=" + signin.generateRandomAlphaNum(8);
				} else {
					url = $Model.oAuthEntityResult.AuthorizationURL + "?client_id=" + $Model.oAuthEntityResult.OC_ClientID + "&redirect_uri=" +
						encodeURIComponent(currentURL) + "&lang=" + language.substring(0, 2) + "&scope=" + $Model.oAuthEntityResult.Scope + "&response_type=" +
						$Model.oAuthEntityResult.ResponseType + "&response_mode=" + $Model.oAuthEntityResult.ResponseMode + "&state=" + signin.generateRandomAlphaNum(8);
				}
				window.location.href = url;
			});
			return;
		}
		// 校验输入框是否都已必填
		var flagname = $fire.validate("$Model.name", $Scope);
        if (!flagname)
        {
        	$("#ipt_name").focus();
        	return;
        }
		var flagpwd = $fire.validate("$Model.pwd", $Scope);
		if (!flagpwd)
        {
        	$("#ipt_pwd").focus();
        	return;
        }
		var flag = $fire.validate("$Model.name,$Model.pwd,$Model.langProperty,$Model.vcode", $Scope);
        if (!flag)
        {
        	$("#ipt_name").focus();
        	return;
        }
		
        var ipMac = signin.getIpMac($Scope);
        var mac = "";
        var ip = "";
        if (ipMac != "")
        {
        	mac = ipMac.split(";")[0];
            ip = ipMac.split(";")[1];
        }
        
		//call service
        window.issubmited = true;

        //不在规定的IP段内并且图形验证码不打开，则走新增的校验图形验证码逻辑，成功之后继续走原有逻辑
        if (!$Model.ipResult && !$Model.initParams.needGraphicVerifyCode) {
        	$fire({
        		"service" : "/checktoken/checkverifycode",
        		"params" :  {'inputVerifyCodeStr':vcode},
        		"target" : "$Model.result",
        	},$Scope).onafter(function(){
        		if($Model.result){
        			debugger;
        			var loginparam = {};
        			loginparam.userName = username;
        			loginparam.password = encryptWithRSA("[" + $Model.loginRandomValue + "]" + pwd);
        			loginparam.locale = language;
        			loginparam.verifyCode = vcode;
        			loginparam.ipAddr = ip;
        			loginparam.macAddr = mac;
        			
        			loginparam.accountType = $Model.selectedAccountType;
        			$fire({
        				"service" : "SMAuthenticateAction/authenticatelogin",
        				"params" :  {'loginparam':loginparam},
        				"target" : "$Model.authResult",
        				"onerror" : "signin.onAuthException($Model)"
        			},$Scope).onafter(function(){
        				debugger;
        				signin.onAuthAfter($Scope);
        			});
        		}else{
        			debugger;
        			signin.onCheckException($Model);
        		}
        		
        		
        	});
		}else{
			//1.是外网并且图形验证码打开   2.在内网
			debugger;
			var loginparam = {};
			loginparam.userName = username;
			loginparam.password = encryptWithRSA("[" + $Model.loginRandomValue + "]" + pwd);
			loginparam.locale = language;
			loginparam.verifyCode = vcode;
			loginparam.ipAddr = ip;
			loginparam.macAddr = mac;
			
			loginparam.accountType = $Model.selectedAccountType;
			$fire({
				"service" : "SMAuthenticateAction/authenticatelogin",
				"params" :  {'loginparam':loginparam},
				"target" : "$Model.authResult",
				"onerror" : "signin.onAuthException($Model)"
			},$Scope).onafter(function(){
				debugger;
				signin.onAuthAfter($Scope);
			});
		}
        
        
        
	};

	this.generateRandomAlphaNum = function (len) {
		var rdmString = "";
		for( ; rdmString.length < len; rdmString  += Math.random().toString(36).substr(2));
		return  rdmString.substr(0, len);
	};
	
	//校验图形验证码失败
	this.onCheckException = function($Model)
	{
		window.issubmited = false;
		
		var i18n = $UEE.i18n;
		signin.showError(i18n('SM.LOGIN.LABEL.SYSTEM_CHECK_VERIFY_CODE_ERROR'));
	};
	
	// 判断是否IE
	this.isIE = function($Scope)
	{
		if (navigator.userAgent.indexOf("MSIE") > 0) 
		{
			return true;
		}
		return false;
	};
	
	// 获取IP地址和Mac
	this.getIpMac = function($Scope)
	{
		debugger;
		var ipmac = ""; 
		
		if (signin.isIE($Scope))
		{
			var locator = new ActiveXObject ("WbemScripting.SWbemLocator"); 
		    var service = locator.ConnectServer(".");
		    //获取当前在用MAC，排除虚拟网卡
	        var properties = service.ExecQuery("SELECT MACAddress FROM Win32_NetworkAdapter WHERE ((MACAddress Is Not NULL) AND (Manufacturer <> 'Microsoft')) AND (NetConnectionStatus=2 OR NetConnectionStatus=9)"); 
	        var e = new Enumerator (properties); 
	         
	        var mac = "";
	        
	        for (; !e.atEnd(); e.moveNext())
	        {
	             var p = e.item();  
	             mac = "" + p.MACAddress;
	             break;
	        }
	        if(mac == null)
	        {
	            ipmac = "";
	            ip = "";
	        }
	        else if (mac != "")
	        {
			   //根据MAC获取相应IP，排除本机地址
	            properties = service.ExecQuery("SELECT IPAddress,MACAddress FROM Win32_NetworkAdapterConfiguration"); 
	            e = new Enumerator (properties); 
	            for (; !e.atEnd(); e.moveNext())
	            {            	
	                 var p = e.item();                 
	                 var ip = "" + p.IPAddress(0);
	                 var m = "" + p.MACAddress;
	                 if(ip != "" && ip != "0.0.0.0" && m==mac)
	                 {
	                     ipmac = ip;
	                     break;
	                 }
	            }            
	            ipmac = mac.replace(/:/g, "-")+";"+ipmac;
	        }         
	         
	        e = null;
	        properties = null;
		}
		
        return ipmac;
	};
	
	this.onAuthAfter = function($Scope)
	{
		debugger;
		var i18n = $UEE.i18n;
		
		//请求回来后，将变量重新置为false
		window.issubmited = false;
		var $Model = $Scope.$Model;
		//根据操作员账号查询操作员状态及status changing reason,
		var userName = $Model.name;
		var $fire = $Scope.$Get('$Fire');
		
		var jsonObj = $Model.authResult;
		if (!jsonObj)
		{
			signin.showError(i18n('SM.LOGIN.LABEL.SYSTEM_ERROR'));
			document.getElementById("loginBtn").style.display="";
			document.getElementById("localeDiv").style.display="";
			return;
		}
		
		if (!jsonObj.success) 
		{
			document.getElementById("loginBtn").style.display="";
			document.getElementById("localeDiv").style.display="";
			if (!jsonObj.visitBelongedSystem && jsonObj.belongedSystemURL != undefined)
			{
				window.top.location.href = jsonObj.belongedSystemURL;
				return;
			}
			
			var errNo = jsonObj.errorNo;
			var errMsg = "";
			
			//判断组织状态
			if (errNo == "60101020051")
			{
				$Model.authResult.errorMsg = "";
                // Dealer Configuration CRD
				$fire({
					"service" : "/SMIsDealerOperator/isDealerOperator",
					"params" : {"employeeCode" : userName},
					"target" : "$Model.isDealerOperator"
				},$Scope).onafter(function(){
					if($Model.isDealerOperator)
					{
						errMsg = i18n('SM.LOGIN.LABEL.IS_DEALER_OPERATOR_STATUS_DISABLED');
						signin.showError(errMsg);
						return false;
					}
					else
					{
						errMsg = i18n('SM.LOGIN.LABEL.OU_STATUS_DISABLED');
						signin.showError(errMsg);
						return false;
					}
				})
				return;
			}			
			
			//如果操作员状态为2-挂起，显示操作员状态修改原因
			if (errNo == "60101020050")
			{
				$fire({
					"service" : "/SMIsEmployeeSuspend/isemployeesuspend",
					"params" : {"employeeCode" : userName}
				},$Scope).onerror(function(){
					debugger;
					errMsg = $Scope.$Error.cause;
					signin.showError(errMsg);
					return false;
				}).onafter(function(){
					errMsg = i18n(jsonObj.errorMsg) ? i18n(jsonObj.errorMsg) : i18n('SM.LOGIN.LABEL.SYSTEM_ERROR');
					signin.showError(errMsg);
				});
				return;
			}
			else
			{
				errMsg = i18n(jsonObj.errorMsg) ? i18n(jsonObj.errorMsg) : i18n('SM.LOGIN.LABEL.SYSTEM_ERROR');
				signin.showError(errMsg);
				return;
			}			
		}
        if (window.Storage && window.localStorage && window.localStorage instanceof Storage) {
            window.localStorage.setItem("inputLoginId", $Model.name);
        }
		signin.go2Next($Scope, jsonObj);
	};
	
	this.onAuthException = function($Model)
	{
		window.issubmited = false;
		
		var i18n = $UEE.i18n;
		signin.showError(i18n('SM.LOGIN.LABEL.SYSTEM_ERROR'));
	};
	
	this.showInfo = function(errorMsg)
	{
		$("#div_error").html(errorMsg);
		$("#div_error").css({
			visibility : "visible",color:"#32CD32"
		});
	};
	
	this.showError = function(errorMsg)
	{
		$("#div_error").html(errorMsg);
		$("#div_error").css({
			visibility : "visible",color:"red"
		});
		
		if(needVerifyCode)
		{
			refreshVerifycode();			
		}
		var $Scope = $(document).scope();
		var $fire = $Scope.$Get("$Fire");
		$fire({
		      "service" : "SMLoginAction/getLoginRandomValue",
		      "target" : "$Model.loginRandomValue",
		 },$Scope);
	};
	
	//成功后重定向到主框架页面或其他强制修改密码页面
	this.go2Next = function($Scope, jsonObj)
	{
		debugger;
		//密码修改处理
		if(typeof(jsonObj.redirectFlag) != "undefined")
		{
			var i18n = $UEE.i18n;
			//强制修改密码，取消后退出系统。PEFM:密码过期强制修改密码 ；FLFM：首次登录强制修改密码
			if(jsonObj.redirectFlag == "PEFM" || jsonObj.redirectFlag == "FLFM"){
				var popTitle = '';
				if(jsonObj.redirectFlag == "PEFM")
				{
					popTitle = i18n('SM.LOGIN.TITLE.PASSWORD_HASEXPIRED');
				}
				else
				{
					popTitle = i18n('SM.LOGIN.TITLE.PASSWORD_INIT');
				}
				var $fire0 = $Scope.$Inject("$Fire");
				$fire0({"popup" : {'title' : popTitle,'width' : '560px','height' : '380px','modal' : true, 'src':'resource.root/bes/sm/login/forcechangepwd.html'}
				      },$Scope).onafter(function(){
							var $Model = $Scope.$Model;
							var popRet = $Model.popRet;
							if(popRet == '1') //用户点取消或者关闭界面，直接登出
							{
								var $fire1 = $Scope.$Inject("$Fire");
								$fire1({
									"service" : "SMLogoutAction/logout"
								},$Scope).onafter(function(){
									$fire1({
									      "service" : "SMLoginAction/getLoginRandomValue",
									      "target" : "$Model.loginRandomValue",
									 },$Scope);
								});
							}
							else //用户点确定，转到修改密码界面
							{
								var url = $(document).scope().$Webapp + "/bes/sm/login/portal.html";
								signin.forwardUrl(url, jsonObj);
							}
				});
				return;
			}
			//普通的修改密码，取消后可以进入系统。FLOM：首次登录可选修改密码；PETM：密码即将过期提示，可选修改密码
			else if(jsonObj.redirectFlag == "FLOM" || jsonObj.redirectFlag == "PETM"){
				var popTitle = '';
				if(jsonObj.redirectFlag == "FLOM")
				{
					popTitle = i18n('SM.LOGIN.TITLE.PASSWORD_INIT_SHOULD');
				}
				else
				{
					popTitle = i18n('SM.LOGIN.TITLE.PASSWORD_WILLEXPIRED');
				}
				var $fire = $Scope.$Inject("$Fire");
				$fire({"popup" : {'title' : popTitle,'width' : '560px','height' : '380px','modal' : true, 'src':'resource.root/bes/sm/login/forcechangepwd.html'}
				      },$Scope).onafter(function(){
							var $Model = $Scope.$Model;
							var popRet = $Model.popRet;
							if(popRet == '1') //用户点取消或者关闭界面，转到主页
							{
								var url = $(document).scope().$Webapp + "/bes/sm/login/portal.html";
								signin.forwardUrl(url, jsonObj);
							}
							else //用户修改密码成功，转到主页
							{
								var url = $(document).scope().$Webapp + "/bes/sm/login/portal.html";
								signin.forwardUrl(url, jsonObj);
							}
				});
				return;
			}
		}
		
		//原始登陆页面跳转
		if (typeof(jsonObj.nextAction) != "undefined" && jsonObj.nextAction)
		{
			var url=$(document).scope().$Webapp + "/" + jsonObj.nextAction;
			signin.forwardUrl(url, jsonObj);
			return;
		}
		
		//主页面
		var siteId = $Scope.$Params.siteId;
		var redirectUrl = $Scope.$Params.redirectUrl;		
		while (redirectUrl && redirectUrl.indexOf('/') == 0) {
			redirectUrl = redirectUrl.substring(1);
		}
		
		var url;
		if (siteId) {
			url = $(document).scope().$Webapp + "/bes/sm/login/portal.html?siteId=" + siteId;
			if (redirectUrl) {
				url = url + "&redirectUrl=" + redirectUrl;
			}
		} else {
			url = $(document).scope().$Webapp + "/bes/sm/login/portal.html";
			if (redirectUrl) {
				url = url + "?redirectUrl=" + encodeURIComponent(redirectUrl);
			}
		}
		signin.forwardUrl(url, jsonObj);
	};
}

window.issubmited = false;

var signin = new Signin();

// 回车登录
document.onkeydown = function(event) {
	
	if ($(document).scope().$Model.isBesDisabledDebug){ 
        // 禁用F12  ---start
    	var keyCode = 123;				//F12的逻辑键值
        if(event.keyCode == keyCode){         //通过键值判断是否是F12
            event.keyCode=0;  
            event.returnValue=false;    //不进行任何操作
            return false;
        }  
        // 禁用F12---end
    }
	
	var srcId; //loginBtn
    if (!event)
    {
    	event = window.event;
    	srcId = event.srcElement.id;
    }
    else
    {
    	srcId = event.target.id; 
    }
    if(srcId == "loginBtn")
    {
        return;
    }
    var keycode = $.browser.mozilla?event.which:event.keyCode;
    if(keycode == 13 && $('.popwin')[0] == undefined)
    {
        $('#loginBtn').click();
        return false;
    }
};

$(document).ready(function() 
{
	//用户已登出，如果是主框架页面则刷新到登录界面
	if (window.parent != window) {
		window.parent.location.href = $(document).scope().$Webapp + "/bes/sm/login/login.html";
	}

	var verifycodesrc = $(document).scope().$Webapp + "/verifycode";
	
	window.refreshVerifycode = function(){
		$('#validateimg').attr('src',verifycodesrc + '?r=' + Math.random());
	};
	
	window.getLangDiv = function(lanKey, lanValue){
		var str = '<option value="' + lanKey + '" ng-selected="$input.isSelected[item.key]" test-option="" class="ng-binding ng-scope">' + lanValue + '</option>';
		return $(str);
	};
});
